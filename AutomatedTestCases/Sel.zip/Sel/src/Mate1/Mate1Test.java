package Mate1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Mate1Test {


	@Test
	public void testOne() throws Exception {

		//TestCaseNo.4 and 5 from Mate1-Manual Test Cases.xlsx
		//Login and checking for all the options in the main page
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.mate1.com/");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='header-container']/div/a")).click();
		Thread.sleep(5000);
		driver.switchTo().frame(driver.findElement(By.xpath("/html/body/div[3]/div/iframe")));
		driver.findElement(By.xpath("//*[@id='email']")).sendKeys("i.am.nikki.n@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Sairam@24x7");
		driver.findElement(By.xpath("//*[@id='member_login']/div[5]/input")).click();
		Thread.sleep(15000);
		
		//TestCaseNo. 7 and 8 from Mate1-Manual Test Cases.xlsx
		// Different tests in edit/view profile section
		driver.findElement(By.xpath("//*[@id='profile_dd_li']/a")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='profile_dd_li']/ul/li[2]/a")).click();
		Thread.sleep(15000);
		driver.findElement(By.xpath("//*[@id='title']")).sendKeys("Hello");
		driver.findElement(By.xpath("//*[@id='profileLooking_gender']")).sendKeys("Man");
		driver.findElement(By.xpath("//*[@id='input_postalCode']")).sendKeys("H3H2G9");
		driver.findElement(By.xpath("//*[@id='submit_basic_information']")).click();
		Thread.sleep(15000);
		
		//TestCaseNo.9, 10, 11 and 12 from Mate1-Manual Test Cases.xlsx
		//Checking the validity of text in about me section
		driver.findElement(By.xpath("//*[@id='aboutMyself']")).sendKeys(
				"vbzrewrewrewerererewrwerodjfgijgdhvfhdncxljvnclkhvklfhbksffhdsbkjdsbvbdsbvdbvdsjvbdjsvbdjvbdvbsdjbjvkdbvdbcnxbvkjdsfvbjvbfdjskvn.k,bc.kvj,vn.sj,vbn.vbfjvb.sfvbs.jvbsjvsdljvbsdljbvsjdbvds.kjbvosdvs;odfuvb;osejvln fdkjn.kjvbfsovls;24x7vbzrewrewrewerererewrwerodjfgijgdhvfhdncxljvnclkhvklfhbksffhdsbkjdsbvbdsbvdbvdsjvbdjsvbdjvbdvbsdjbjvkdbvdbcnxbvkjdsfvbjvbfdjskvn.k,bc.kvj,vn.sj,vbn.vbfjvb.sfvbs.jvbsjvsdljvbsdljbvsjdbvds.kjbvosdvs;odfuvb;osejvln fdkjn.kjvbfsovls;24x7vbzrewrewrewerererewrwerodjfgijgdhvfhdncxljvnclkhvklfhbksffhdsbkjdsbvbdsbvdbvdsjvbdjsvbdjvbdvbsdjbjvkdbvdbcnxbvkjdsfvbjvbfdjskvn.k,bc.kvj,vn.sj,vbn.vbfjvb.sfvbs.jvbsjvsdljvbsdljbvsjdbvds.kjbvosdvs;odfuvb;osejvln fdkjn.kjvbfsovls;24x7vbzrewrewrewerererewrwerodjfgijgdhvfhdncxljvnclkhvklfhbksffhdsbkjdsbvbdsbvdbvdsjvbdjsvbdjvbdvbsdjbjvkdbvdbcnxbvkjdsfvbjvbfdjskvn.k,bc.kvj,vn.sj,vbn.vbfjvb.sfvbs.jvbsjvsdljvbsdljbvsjdbvds.kjbvosdvs;odfuvb;osejvln fdkjn.kjvbfsovls;24x7vbzrewrewrewerererewrwerodjfgijgdhvfhdncxljvnclkhvklfhbksffhdsbkjdsbvbdsbvdbvdsjvbdjsvbdjvbdvbsdjbjvkdbvdbcnxbvkjdsfvbjvbfdjskvn.k,bc.kvj,vn.sj,vbn.vbfjvb.sfvbs.jvbsjvsdljvbsdljbvsjdbvds.kjbvosdvs;odfuvb;osejvln fdkjn.kjvbfsovls;24x7vbzrewrewrewerererewrwerodjfgijgdhvfhdncxljvnclkhvklfhbksffhdsbkjdsbvbdsbvdbvdsjvbdjsvbdjvbdvbsdjbjvkdbvdbcnxbvkjdsfvbjvbfdjskvn.k,bc.kvj,vn.sj,vbn.vbfjvb.sfvbs.jvbsjvsdljvbsdljbvsjdbvds.kjbvosdvs;odfuvb;osejvln fdkjn.kjvbfsovls;24x7vbzrewrewrewerererewrwerodjfgijgdhvfhdaaaaqqqqdfs//*[id='submit_basic_information']//*[id='submit_ba");
		driver.findElement(By.xpath("//*[@id='submit_about_myself']")).click();
		driver.findElement(By.xpath("//*[@id='container_about_myself']/div[2]/div[2]/a")).click();
		Thread.sleep(5000);
		String val = (driver.findElement(By.xpath("//*[@id='about_myself']/div")).getText());
        String val1 = val.substring(0, 1);
        	if (val1.length() > 0){
        		System.out.println("Error with the text which is entered");
        	}
		driver.findElement(By.linkText("Log Out")).click();
	}
}